import java.rmi.*;
import java.rmi.server.*;
public class servant extends UnicastRemoteObject implements Inter{

	public servant() throws RemoteException{}
	
	public int puissance(int n) throws RemoteException{
		int nn = n*n;
		return nn;
	}
}
