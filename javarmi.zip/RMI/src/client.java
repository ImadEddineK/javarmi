import java.net.MalformedURLException;
import java.rmi.*;


public class client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Inter obj = (Inter) Naming.lookup("rmi://localhost:1099/od");
			int n=obj.puissance(2);
			System.out.println(n);
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
