import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class serveur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			servant OD = new servant();
			Registry register = LocateRegistry.createRegistry(1099);
			Naming.rebind("od", OD);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
