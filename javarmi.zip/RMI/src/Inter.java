import java.rmi.*;
public interface Inter extends Remote{
	public int puissance(int n) throws RemoteException;
}
